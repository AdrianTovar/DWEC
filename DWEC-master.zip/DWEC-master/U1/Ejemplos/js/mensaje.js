alert(t);
console.log("Esto es una cadena");
console.info("Esto es info");
console.warn("Esto es un aviso");
console.error("Esto es un error");

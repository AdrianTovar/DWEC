var s = new Surtido(productos);
s.dibujarSurtido();
